var logOut = document.getElementById('logOut');
logOut.addEventListener('click', function() {
    window.location.href = "log-out.php";
});

var Accc = document.getElementById('account');
Accc.addEventListener('click', function() {
    window.location.href = "account.php";
});