<?php
$costoption=[ 'cost'=>12];
$hashedpwd=password_hash($password,PASSWORD_DEFAULT,$costoption);